ocr com erro tem 60 dpi

original tem 500 dpi

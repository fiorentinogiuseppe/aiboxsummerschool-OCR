from django.apps import AppConfig


class PostprocessingConfig(AppConfig):
    name = 'postprocessing'
